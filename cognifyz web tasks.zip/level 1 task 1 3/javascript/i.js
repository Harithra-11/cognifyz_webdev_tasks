$(".hamburger").click(function(){
    $(".wrapper").toggleClass("collapse");
 });